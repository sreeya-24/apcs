
/**
 * This is the processing interface.
 *
 * @author Sreeya Gambhirrao
 * @version 04/17/2022
 */
public interface Processing
{
    public abstract void doReading();
}
