
/**
 * This is the child class of Vehicle.
 *
 * @author Sreeya Gambhirrao
 * @version 04/18/2022
 */
public class Car extends Vehicle
{
    // instance variables - replace the example below with your own
    private int x;

    /**
     * Constructor for objects of class Car
     */
    public Car(String name, double cost)
    {
        super(name, cost);
    }
}
