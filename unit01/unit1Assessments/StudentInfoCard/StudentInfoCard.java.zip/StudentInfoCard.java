
/**
 * This program will will display a series of strings 
 * stating my name,birthday,the school,etc.
 *
 * @author (Sreeya Gambhirrao)
 * @version (9.30.2021)
 */
public class StudentInfoCard
{
   public static void main(String[] args){
       System.out.println("*******************************************************************************************");
       System.out.println("*                                                                                         *");
       System.out.println("*                                   Student Information                                   *");
       System.out.println("*                                                                                         *");
       System.out.println("*******************************************************************************************");
       System.out.println();
       System.out.print("Name: Sreeya Gambhirrao"); 
       System.out.print("             Birthday: 08.24.2005");
       System.out.println("              My Age: 16 years");
       System.out.println();
       System.out.print("School: California High School");
       System.out.print("      Grade Level: 11th grade");
       System.out.println("           City: San Ramon");
       System.out.println();
       System.out.print("Home Phone #: 650-242-8018");
       System.out.println("          Available Timings: Sat-Sun, 2:00pm-5:00pm PST");
       System.out.println("Cell Phone #: 925-856-6009");
       System.out.println();
       System.out.println("Current Math Course: Pre-calculus");
       System.out.println("Experience: Beginner JavaScript.");  
       System.out.println();
       System.out.println("Why I have chosen to take this course: I have realized over my time of researching");
       System.out.println("in medicine that almost every career in medicine involves computer science");
       System.out.println("and computer science skills. I though of using my skills in computer science to"); 
       System.out.print("contribute in the field of medicine.");
   }
}
