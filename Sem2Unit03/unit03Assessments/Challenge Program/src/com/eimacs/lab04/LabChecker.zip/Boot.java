package src.com.eimacs.lab04;

/**
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class Boot extends Footwear
{
    public Boot(String style, double size, String sku)
    {
        super(style,size,sku);
    }
    
    public String getType()
    {
        return "Boot";
    }
}
