package src.com.eimacs.lab04;

/**
 *
 * @author |Your name|
 * @version 1.0 |Today's date|
 */
public class CasualShoe extends Shoe
{
    public CasualShoe(String style, double size, String sku)
    {
        super(style, size, sku);
    }
    
    public String getType()
    {
        return "Casual Shoe";
    }
}
