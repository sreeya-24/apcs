
/**
 * This program prints the verses and choruses of the song Butter from BTS.
 *
 * @author Sreeya Gambhirrao
 * @version 11/6/2021
 */
public class ButterLyrics
{
   
    public static void main(String[]args)
    {
        //local Variables
        //Verse 1
        String row1 = "Smooth like butter, like a criminal undercover";
        String row2 = "Gon' pop like trouble breaking into your heart like that";
        String row3 = "Cool shade, stunner, yeah, I owe it all to my mother";
        String row4 = "Hot like summer, yeah, I'm making you sweat like that";
        //chorus lines
        String row5 = "Ooh, when I look in the mirror, I'll melt your heart into two";
        String row6 = "I got that superstar glow, so Ooh";
        String row7 = "Side step, right-left, to my beat";
        String row8 = "High like the moon, rock with me, baby";
        String row9 = "Know that I got that heat, Let me show you 'cause talk is cheap";
        String row10 = "Side step, right-left, to my beat";
        String row11 = "Get it, let it roll!";
        //Verse 2
        String row12 = "Smooth like butter, pull you in like no other";
        String row13 = "Don't need no Usher to remind me you got it bad";
        String row14 = "Ain't no other that can sweep you up like a robber";
        String row15 = "Straight up, I got ya";
        String row16 = "Making you fall like that";
        
        //print verses
        System.out.println(" Butter");
        System.out.println(" BTS, 2021");
        System.out.println("********************************************************************");
        System.out.println();
        
        System.out.println(row1);
        System.out.println(row2);
        System.out.println(row3);
        System.out.println(row4);
        System.out.println();
        System.out.println(row5);
        System.out.println(row6);
        System.out.println(row7);
        System.out.println(row8);
        System.out.println(row9);
        System.out.println(row10);
        System.out.println(row11);
        System.out.println();
        System.out.println(row12);
        System.out.println(row13);
        System.out.println(row14);
        System.out.println(row15);
        System.out.println(row16);
        System.out.println();
        System.out.println(row5);
        System.out.println(row6);
        System.out.println(row7);
        System.out.println(row8);
        System.out.println(row9);
        System.out.println(row10);
        System.out.println(row11);



    }
}
