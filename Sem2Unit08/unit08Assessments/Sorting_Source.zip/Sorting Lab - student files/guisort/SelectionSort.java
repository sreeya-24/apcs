package guisort;

/**
 * Demonstrates Selection Sort on an array of integers.
 */
public class SelectionSort {
    private DynamicArrayChart chart;
    
    public SelectionSort() {
        /* Create an array of integers named array with 1-20 elements. 
         * Element values must be from 1-50. */

     
        /* Create a new DynamicArrayChart and assign it to variable chart. */
        
     
        /* Set array to null. */
    
     
        /* Call the runSort() method. */

    }
    
    private void runSort() {
        /* Implement the Selection Sort algorithm.
         * All queries and modifications to the original array can be done with
         * method calls on the chart object. */

    }
    
    public static void main(String[] args) {
        new SelectionSort();
    }
}
